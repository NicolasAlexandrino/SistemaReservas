# Sistema de Reservas

API REST para gerenciar hóspedes, quartos e reservas de um hotel. O sistema usa
Spring Boot, Spring Data JPA e PostgreSQL, com validação de entrada, regras de
negócio e documentação OpenAPI.

## Tecnologias

- Java 25 e Spring Boot
- Spring Web MVC, Spring Data JPA e Bean Validation
- PostgreSQL
- Springdoc OpenAPI / Swagger UI
- Maven Wrapper

## Executar

1. Instale o Java 25 e deixe o PostgreSQL em execução.
2. Crie ou confirme o banco `SistemaReserva`.
3. Confira a URL, usuário e senha do banco em
   `src/main/resources/application.properties`; ajuste-os para o ambiente local.
4. Na raiz do projeto, execute:

   ```powershell
   .\mvnw.cmd spring-boot:run
   ```

A aplicação fica disponível em `http://localhost:8080`. O Hibernate está
configurado para atualizar o esquema (`ddl-auto=update`), sem recriar o banco.

## Interface web

O painel integrado fica em `http://localhost:8080/`. Ele usa a mesma origem da
API e permite cadastrar, listar, editar e excluir hóspedes, quartos e reservas,
aplicar filtros, cancelar reservas e acompanhar um resumo da operação. As
mensagens e erros exibidos no painel vêm das respostas HTTP do backend.

## Documentação

- Swagger UI: `http://localhost:8080/swagger-ui/index.html`
- OpenAPI JSON: `http://localhost:8080/v3/api-docs`

## Endpoints

Todos os recursos têm operações para listar, consultar por ID, criar, atualizar
e excluir. As criações retornam `201 Created`, as consultas/atualizações retornam
`200 OK` e as exclusões retornam `204 No Content`. IDs inexistentes retornam
`404`; erros de validação, `400`; conflitos com as regras do domínio, `409`.

| Recurso | Endpoints | Filtros |
|---|---|---|
| Hóspedes | `/hospedes`, `/hospedes/{id}` | `nome`, `email` |
| Quartos | `/quartos`, `/quartos/{id}` | `tipo`, `disponivel`, `capacidadeMinima` |
| Reservas | `/reservas`, `/reservas/{id}` | `status`, `hospedeId`, `quartoId`, `dataInicio`, `dataFim` |

`DELETE /reservas/{id}` exclui a reserva. Para cancelar sem excluir o registro,
use `PATCH /reservas/{id}/cancelamento`.

### Exemplos

Cadastrar um hóspede:

```http
POST /hospedes
Content-Type: application/json

{
  "nome": "Ana Souza",
  "email": "ana@example.com",
  "telefone": "11999990000"
}
```

Cadastrar um quarto:

```http
POST /quartos
Content-Type: application/json

{
  "numero": 101,
  "tipo": "Standard",
  "capacidade": 2,
  "valorDiaria": 250.00,
  "disponivel": true
}
```

Criar uma reserva (substitua os IDs pelos registros cadastrados):

```http
POST /reservas
Content-Type: application/json

{
  "dataCheckin": "2026-12-10",
  "dataCheckout": "2026-12-13",
  "quantidadeHospedes": 2,
  "hospedeId": 1,
  "quartoId": 1
}
```

O valor total é calculado automaticamente pela quantidade de diárias vezes o
valor da diária do quarto.

Exemplos de filtros:

```http
GET /hospedes?nome=ana&email=example.com
GET /quartos?tipo=standard&disponivel=true&capacidadeMinima=2
GET /reservas?status=CONFIRMADA&dataInicio=2026-12-01&dataFim=2026-12-31
```

## Regras de negócio

- E-mail de hóspede e número de quarto não podem ser duplicados.
- Uma reserva exige check-out posterior ao check-in, quarto disponível,
  capacidade suficiente e ausência de outra reserva ativa que sobreponha o
  período.
- O total da reserva é calculado com base nas diárias e no preço atual do quarto.
- Hóspedes e quartos com reservas vinculadas não podem ser excluídos.
- Reservas canceladas não podem ser alteradas; reservas encerradas não podem ser
  canceladas.

Os erros são retornados em JSON com data/hora, status HTTP, descrição e mensagem.
