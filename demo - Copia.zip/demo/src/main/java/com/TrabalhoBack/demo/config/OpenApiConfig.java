package com.TrabalhoBack.demo.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI reservaOpenAPI() {
        return new OpenAPI().info(new Info()
                .title("Sistema de Reservas")
                .description("API REST para cadastro de hóspedes, quartos e reservas.")
                .version("1.0.0"));
    }
}
