package com.TrabalhoBack.demo.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

public record ReservaDTO(
        Long id,
        LocalDate dataCheckin,
        LocalDate dataCheckout,
        Integer quantidadeHospedes,
        BigDecimal valorTotal,
        String status,
        Long hospedeId,
        String nomeHospede,
        Long quartoId,
        Integer numeroQuarto) {
}
