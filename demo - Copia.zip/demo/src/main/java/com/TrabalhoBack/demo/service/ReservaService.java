package com.TrabalhoBack.demo.service;

import com.TrabalhoBack.demo.dto.ReservaDTO;
import com.TrabalhoBack.demo.dto.ReservaRequestDTO;
import com.TrabalhoBack.demo.exception.BusinessException;
import com.TrabalhoBack.demo.exception.InvalidRequestException;
import com.TrabalhoBack.demo.exception.ResourceNotFoundException;
import com.TrabalhoBack.demo.model.Hospede;
import com.TrabalhoBack.demo.model.Quarto;
import com.TrabalhoBack.demo.model.Reserva;
import com.TrabalhoBack.demo.repository.HospedeRepository;
import com.TrabalhoBack.demo.repository.QuartoRepository;
import com.TrabalhoBack.demo.repository.ReservaRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

@Service
@Transactional
public class ReservaService {

    private static final String CONFIRMADA = "CONFIRMADA";
    private static final String CANCELADA = "CANCELADA";

    private final ReservaRepository reservaRepository;
    private final HospedeRepository hospedeRepository;
    private final QuartoRepository quartoRepository;

    public ReservaService(
            ReservaRepository reservaRepository,
            HospedeRepository hospedeRepository,
            QuartoRepository quartoRepository) {
        this.reservaRepository = reservaRepository;
        this.hospedeRepository = hospedeRepository;
        this.quartoRepository = quartoRepository;
    }

    @Transactional(readOnly = true)
    public List<ReservaDTO> listar(
            String status, Long hospedeId, Long quartoId,
            LocalDate dataInicio, LocalDate dataFim) {
        if (dataInicio != null && dataFim != null && dataInicio.isAfter(dataFim)) {
            throw new InvalidRequestException(
                    "A data inicial não pode ser posterior à data final.");
        }
        String statusNormalizado = status == null || status.isBlank()
                ? null : status.trim().toUpperCase();
        return reservaRepository.buscarComFiltros(
                        statusNormalizado, hospedeId, quartoId, dataInicio, dataFim)
                .stream().map(this::paraDTO).toList();
    }

    @Transactional(readOnly = true)
    public ReservaDTO buscarPorId(Long id) {
        return paraDTO(obterReserva(id));
    }

    public ReservaDTO criar(ReservaRequestDTO dto) {
        validarDatas(dto.dataCheckin(), dto.dataCheckout());
        Hospede hospede = obterHospede(dto.hospedeId());
        Quarto quarto = obterQuarto(dto.quartoId());
        validarReserva(dto, quarto, null);

        Reserva reserva = new Reserva();
        aplicarDados(reserva, dto, hospede, quarto);
        reserva.setStatus(CONFIRMADA);
        return paraDTO(reservaRepository.save(reserva));
    }

    public ReservaDTO atualizar(Long id, ReservaRequestDTO dto) {
        validarDatas(dto.dataCheckin(), dto.dataCheckout());
        Reserva reserva = obterReserva(id);
        if (CANCELADA.equals(reserva.getStatus())) {
            throw new BusinessException("Uma reserva cancelada não pode ser alterada.");
        }

        Hospede hospede = obterHospede(dto.hospedeId());
        Quarto quarto = obterQuarto(dto.quartoId());
        validarReserva(dto, quarto, id);
        aplicarDados(reserva, dto, hospede, quarto);
        return paraDTO(reservaRepository.save(reserva));
    }

    public void cancelar(Long id) {
        Reserva reserva = obterReserva(id);
        if (CANCELADA.equals(reserva.getStatus())) {
            throw new BusinessException("A reserva já está cancelada.");
        }
        if (!reserva.getDataCheckout().isAfter(LocalDate.now())) {
            throw new BusinessException("Não é possível cancelar uma reserva já encerrada.");
        }
        reserva.setStatus(CANCELADA);
        reservaRepository.save(reserva);
    }

    public void excluir(Long id) {
        reservaRepository.delete(obterReserva(id));
    }

    private void validarDatas(LocalDate checkin, LocalDate checkout) {
        if (!checkout.isAfter(checkin)) {
            throw new InvalidRequestException(
                    "O check-out deve ser posterior ao check-in.");
        }
    }

    private void validarReserva(ReservaRequestDTO dto, Quarto quarto, Long idIgnorado) {
        if (!Boolean.TRUE.equals(quarto.getDisponivel())) {
            throw new BusinessException("O quarto selecionado não está disponível para reserva.");
        }
        if (dto.quantidadeHospedes() > quarto.getCapacidade()) {
            throw new BusinessException(
                    "A quantidade de hóspedes excede a capacidade do quarto.");
        }
        if (!reservaRepository.buscarConflitos(
                quarto.getId(), dto.dataCheckin(), dto.dataCheckout(), idIgnorado).isEmpty()) {
            throw new BusinessException(
                    "O quarto já possui uma reserva no período informado.");
        }
    }

    private Hospede obterHospede(Long id) {
        return hospedeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Hóspede não encontrado: " + id));
    }

    private Quarto obterQuarto(Long id) {
        return quartoRepository.findByIdParaReserva(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Quarto não encontrado: " + id));
    }

    private Reserva obterReserva(Long id) {
        return reservaRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Reserva não encontrada: " + id));
    }

    private void aplicarDados(
            Reserva reserva, ReservaRequestDTO dto, Hospede hospede, Quarto quarto) {
        long diarias = ChronoUnit.DAYS.between(dto.dataCheckin(), dto.dataCheckout());
        BigDecimal valorTotal = quarto.getValorDiaria()
                .multiply(BigDecimal.valueOf(diarias));

        reserva.setDataCheckin(dto.dataCheckin());
        reserva.setDataCheckout(dto.dataCheckout());
        reserva.setQuantidadeHospedes(dto.quantidadeHospedes());
        reserva.setHospede(hospede);
        reserva.setQuarto(quarto);
        reserva.setValorTotal(valorTotal);
    }

    private ReservaDTO paraDTO(Reserva reserva) {
        return new ReservaDTO(
                reserva.getId(),
                reserva.getDataCheckin(),
                reserva.getDataCheckout(),
                reserva.getQuantidadeHospedes(),
                reserva.getValorTotal(),
                reserva.getStatus(),
                reserva.getHospede().getId(),
                reserva.getHospede().getNome(),
                reserva.getQuarto().getId(),
                reserva.getQuarto().getNumero());
    }
}
