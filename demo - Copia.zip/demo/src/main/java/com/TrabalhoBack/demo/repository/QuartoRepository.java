package com.TrabalhoBack.demo.repository;

import com.TrabalhoBack.demo.model.Quarto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import jakarta.persistence.LockModeType;
import java.util.List;
import java.util.Optional;

public interface QuartoRepository extends JpaRepository<Quarto, Long> {

    Optional<Quarto> findByNumero(Integer numero);

    boolean existsByNumeroAndIdNot(Integer numero, Long id);

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select q from Quarto q where q.id = :id")
    Optional<Quarto> findByIdParaReserva(@Param("id") Long id);

    @Query("""
            select q from Quarto q
            where (:tipo is null or lower(q.tipo) like lower(concat('%', :tipo, '%')))
              and (:disponivel is null or q.disponivel = :disponivel)
              and (:capacidadeMinima is null or q.capacidade >= :capacidadeMinima)
            order by q.numero
            """)
    List<Quarto> buscarComFiltros(
            @Param("tipo") String tipo,
            @Param("disponivel") Boolean disponivel,
            @Param("capacidadeMinima") Integer capacidadeMinima);
}
