package com.TrabalhoBack.demo.dto;

import java.math.BigDecimal;

public record QuartoDTO(
        Long id, Integer numero, String tipo, Integer capacidade,
        BigDecimal valorDiaria, Boolean disponivel) {
}
