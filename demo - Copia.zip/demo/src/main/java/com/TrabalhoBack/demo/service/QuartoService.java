package com.TrabalhoBack.demo.service;

import com.TrabalhoBack.demo.dto.QuartoDTO;
import com.TrabalhoBack.demo.dto.QuartoRequestDTO;
import com.TrabalhoBack.demo.exception.BusinessException;
import com.TrabalhoBack.demo.exception.InvalidRequestException;
import com.TrabalhoBack.demo.exception.ResourceNotFoundException;
import com.TrabalhoBack.demo.model.Quarto;
import com.TrabalhoBack.demo.repository.QuartoRepository;
import com.TrabalhoBack.demo.repository.ReservaRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class QuartoService {

    private final QuartoRepository quartoRepository;
    private final ReservaRepository reservaRepository;

    public QuartoService(
            QuartoRepository quartoRepository,
            ReservaRepository reservaRepository) {
        this.quartoRepository = quartoRepository;
        this.reservaRepository = reservaRepository;
    }

    @Transactional(readOnly = true)
    public List<QuartoDTO> listar(String tipo, Boolean disponivel, Integer capacidadeMinima) {
        if (capacidadeMinima != null && capacidadeMinima < 1) {
            throw new InvalidRequestException("A capacidade mínima deve ser maior que zero.");
        }
        return quartoRepository.buscarComFiltros(normalizar(tipo), disponivel, capacidadeMinima)
                .stream().map(this::paraDTO).toList();
    }

    @Transactional(readOnly = true)
    public QuartoDTO buscarPorId(Long id) {
        return paraDTO(obterEntidade(id));
    }

    public QuartoDTO criar(QuartoRequestDTO dto) {
        if (quartoRepository.findByNumero(dto.numero()).isPresent()) {
            throw new BusinessException("Já existe um quarto cadastrado com este número.");
        }
        Quarto quarto = new Quarto();
        aplicarDados(quarto, dto);
        return paraDTO(quartoRepository.save(quarto));
    }

    public QuartoDTO atualizar(Long id, QuartoRequestDTO dto) {
        Quarto quarto = obterEntidade(id);
        if (quartoRepository.existsByNumeroAndIdNot(dto.numero(), id)) {
            throw new BusinessException("Já existe um quarto cadastrado com este número.");
        }
        aplicarDados(quarto, dto);
        return paraDTO(quartoRepository.save(quarto));
    }

    public void excluir(Long id) {
        Quarto quarto = obterEntidade(id);
        if (reservaRepository.existsByQuartoId(id)) {
            throw new BusinessException(
                    "Não é possível excluir um quarto que possui reservas vinculadas.");
        }
        quartoRepository.delete(quarto);
    }

    private Quarto obterEntidade(Long id) {
        return quartoRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Quarto não encontrado: " + id));
    }

    private void aplicarDados(Quarto quarto, QuartoRequestDTO dto) {
        quarto.setNumero(dto.numero());
        quarto.setTipo(dto.tipo().trim());
        quarto.setCapacidade(dto.capacidade());
        quarto.setValorDiaria(dto.valorDiaria());
        quarto.setDisponivel(dto.disponivel());
    }

    private QuartoDTO paraDTO(Quarto quarto) {
        return new QuartoDTO(
                quarto.getId(),
                quarto.getNumero(),
                quarto.getTipo(),
                quarto.getCapacidade(),
                quarto.getValorDiaria(),
                quarto.getDisponivel());
    }

    private String normalizar(String filtro) {
        return filtro == null || filtro.isBlank() ? "" : filtro.trim();
    }
}
