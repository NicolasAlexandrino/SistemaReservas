package com.TrabalhoBack.demo.repository;

import com.TrabalhoBack.demo.model.Reserva;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;

public interface ReservaRepository extends JpaRepository<Reserva, Long> {

    @Query("""
            select r from Reserva r
            where (:status is null or r.status = :status)
              and (:hospedeId is null or r.hospede.id = :hospedeId)
              and (:quartoId is null or r.quarto.id = :quartoId)
              and (:dataInicio is null or r.dataCheckin >= :dataInicio)
              and (:dataFim is null or r.dataCheckin <= :dataFim)
            order by r.dataCheckin
            """)
    List<Reserva> buscarComFiltros(
            @Param("status") String status,
            @Param("hospedeId") Long hospedeId,
            @Param("quartoId") Long quartoId,
            @Param("dataInicio") LocalDate dataInicio,
            @Param("dataFim") LocalDate dataFim);

    @Query("""
            select r from Reserva r
            where r.quarto.id = :quartoId
              and r.status <> 'CANCELADA'
              and r.dataCheckin < :dataCheckout
              and r.dataCheckout > :dataCheckin
              and (:idExcluido is null or r.id <> :idExcluido)
            """)
    List<Reserva> buscarConflitos(
            @Param("quartoId") Long quartoId,
            @Param("dataCheckin") LocalDate dataCheckin,
            @Param("dataCheckout") LocalDate dataCheckout,
            @Param("idExcluido") Long idExcluido);

    List<Reserva> findByHospedeId(Long hospedeId);

    List<Reserva> findByQuartoId(Long quartoId);

    boolean existsByHospedeId(Long hospedeId);

    boolean existsByQuartoId(Long quartoId);
}
