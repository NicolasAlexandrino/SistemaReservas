package com.TrabalhoBack.demo.controller;

import com.TrabalhoBack.demo.dto.HospedeDTO;
import com.TrabalhoBack.demo.dto.HospedeRequestDTO;
import com.TrabalhoBack.demo.service.HospedeService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/hospedes")
@Tag(name = "Hóspedes", description = "Cadastro e consulta de hóspedes")
public class HospedeController {

    private final HospedeService hospedeService;

    public HospedeController(HospedeService hospedeService) {
        this.hospedeService = hospedeService;
    }

    @GetMapping
    @Operation(summary = "Lista hóspedes com filtros opcionais por nome e e-mail")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Lista retornada com sucesso"),
            @ApiResponse(responseCode = "400", description = "Parâmetro de consulta inválido")
    })
    public ResponseEntity<List<HospedeDTO>> listar(
            @RequestParam(required = false) String nome,
            @RequestParam(required = false) String email) {
        return ResponseEntity.ok(hospedeService.listar(nome, email));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Busca um hóspede pelo identificador")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Hóspede encontrado"),
            @ApiResponse(responseCode = "404", description = "Hóspede não encontrado")
    })
    public ResponseEntity<HospedeDTO> buscarPorId(@PathVariable Long id) {
        return ResponseEntity.ok(hospedeService.buscarPorId(id));
    }

    @PostMapping
    @Operation(summary = "Cadastra um hóspede")
    @ApiResponses({
            @ApiResponse(responseCode = "201", description = "Hóspede cadastrado"),
            @ApiResponse(responseCode = "400", description = "Dados de entrada inválidos"),
            @ApiResponse(responseCode = "409", description = "E-mail já cadastrado")
    })
    public ResponseEntity<HospedeDTO> criar(@Valid @RequestBody HospedeRequestDTO dto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(hospedeService.criar(dto));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Atualiza os dados de um hóspede")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Hóspede atualizado"),
            @ApiResponse(responseCode = "400", description = "Dados de entrada inválidos"),
            @ApiResponse(responseCode = "404", description = "Hóspede não encontrado"),
            @ApiResponse(responseCode = "409", description = "E-mail já cadastrado")
    })
    public ResponseEntity<HospedeDTO> atualizar(
            @PathVariable Long id, @Valid @RequestBody HospedeRequestDTO dto) {
        return ResponseEntity.ok(hospedeService.atualizar(id, dto));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Exclui um hóspede sem reservas vinculadas")
    @ApiResponses({
            @ApiResponse(responseCode = "204", description = "Hóspede excluído"),
            @ApiResponse(responseCode = "404", description = "Hóspede não encontrado"),
            @ApiResponse(responseCode = "409", description = "Hóspede possui reservas")
    })
    public ResponseEntity<Void> excluir(@PathVariable Long id) {
        hospedeService.excluir(id);
        return ResponseEntity.noContent().build();
    }
}
