package com.TrabalhoBack.demo.dto;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.math.BigDecimal;

public record QuartoRequestDTO(
        @NotNull @Min(1) Integer numero,
        @NotBlank @Size(max = 60) String tipo,
        @NotNull @Min(1) Integer capacidade,
        @NotNull @DecimalMin(value = "0.0", inclusive = false) BigDecimal valorDiaria,
        @NotNull Boolean disponivel) {
}
