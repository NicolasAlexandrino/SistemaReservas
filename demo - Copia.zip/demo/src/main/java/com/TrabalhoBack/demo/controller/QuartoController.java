package com.TrabalhoBack.demo.controller;

import com.TrabalhoBack.demo.dto.QuartoDTO;
import com.TrabalhoBack.demo.dto.QuartoRequestDTO;
import com.TrabalhoBack.demo.service.QuartoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/quartos")
@Tag(name = "Quartos", description = "Cadastro e consulta de quartos")
public class QuartoController {

    private final QuartoService quartoService;

    public QuartoController(QuartoService quartoService) {
        this.quartoService = quartoService;
    }

    @GetMapping
    @Operation(summary = "Lista quartos filtrando por tipo, disponibilidade e capacidade")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Lista retornada com sucesso"),
            @ApiResponse(responseCode = "400", description = "Parâmetro de consulta inválido")
    })
    public ResponseEntity<List<QuartoDTO>> listar(
            @RequestParam(required = false) String tipo,
            @RequestParam(required = false) Boolean disponivel,
            @RequestParam(required = false) Integer capacidadeMinima) {
        return ResponseEntity.ok(quartoService.listar(tipo, disponivel, capacidadeMinima));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Busca um quarto pelo identificador")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Quarto encontrado"),
            @ApiResponse(responseCode = "404", description = "Quarto não encontrado")
    })
    public ResponseEntity<QuartoDTO> buscarPorId(@PathVariable Long id) {
        return ResponseEntity.ok(quartoService.buscarPorId(id));
    }

    @PostMapping
    @Operation(summary = "Cadastra um quarto")
    @ApiResponses({
            @ApiResponse(responseCode = "201", description = "Quarto cadastrado"),
            @ApiResponse(responseCode = "400", description = "Dados de entrada inválidos"),
            @ApiResponse(responseCode = "409", description = "Número do quarto já cadastrado")
    })
    public ResponseEntity<QuartoDTO> criar(@Valid @RequestBody QuartoRequestDTO dto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(quartoService.criar(dto));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Atualiza os dados de um quarto")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Quarto atualizado"),
            @ApiResponse(responseCode = "400", description = "Dados de entrada inválidos"),
            @ApiResponse(responseCode = "404", description = "Quarto não encontrado"),
            @ApiResponse(responseCode = "409", description = "Número do quarto já cadastrado")
    })
    public ResponseEntity<QuartoDTO> atualizar(
            @PathVariable Long id, @Valid @RequestBody QuartoRequestDTO dto) {
        return ResponseEntity.ok(quartoService.atualizar(id, dto));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Exclui um quarto sem reservas vinculadas")
    @ApiResponses({
            @ApiResponse(responseCode = "204", description = "Quarto excluído"),
            @ApiResponse(responseCode = "404", description = "Quarto não encontrado"),
            @ApiResponse(responseCode = "409", description = "Quarto possui reservas")
    })
    public ResponseEntity<Void> excluir(@PathVariable Long id) {
        quartoService.excluir(id);
        return ResponseEntity.noContent().build();
    }
}
