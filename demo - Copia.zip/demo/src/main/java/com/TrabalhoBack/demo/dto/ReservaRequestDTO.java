package com.TrabalhoBack.demo.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

import java.time.LocalDate;

public record ReservaRequestDTO(
        @NotNull LocalDate dataCheckin,
        @NotNull LocalDate dataCheckout,
        @NotNull @Min(1) Integer quantidadeHospedes,
        @NotNull @Min(1) Long hospedeId,
        @NotNull @Min(1) Long quartoId) {
}
