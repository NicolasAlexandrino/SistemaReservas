package com.TrabalhoBack.demo.controller;

import com.TrabalhoBack.demo.dto.ReservaDTO;
import com.TrabalhoBack.demo.dto.ReservaRequestDTO;
import com.TrabalhoBack.demo.service.ReservaService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/reservas")
@Tag(name = "Reservas", description = "Gestão de reservas e disponibilidade")
public class ReservaController {

    private final ReservaService reservaService;

    public ReservaController(ReservaService reservaService) {
        this.reservaService = reservaService;
    }

    @PostMapping
    @Operation(summary = "Cria uma reserva e calcula o valor total")
    @ApiResponses({
            @ApiResponse(responseCode = "201", description = "Reserva criada"),
            @ApiResponse(responseCode = "400", description = "Dados ou datas inválidos"),
            @ApiResponse(responseCode = "404", description = "Hóspede ou quarto não encontrado"),
            @ApiResponse(responseCode = "409", description = "Quarto indisponível ou período conflitante")
    })
    public ResponseEntity<ReservaDTO> criar(@Valid @RequestBody ReservaRequestDTO dto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(reservaService.criar(dto));
    }

    @GetMapping
    @Operation(summary = "Lista reservas com filtros por status, hóspede, quarto e datas")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Lista retornada com sucesso"),
            @ApiResponse(responseCode = "400", description = "Parâmetro de consulta inválido")
    })
    public ResponseEntity<List<ReservaDTO>> listar(
            @RequestParam(required = false) String status,
            @RequestParam(required = false) Long hospedeId,
            @RequestParam(required = false) Long quartoId,
            @RequestParam(required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dataInicio,
            @RequestParam(required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dataFim) {
        return ResponseEntity.ok(
                reservaService.listar(status, hospedeId, quartoId, dataInicio, dataFim));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Busca uma reserva pelo identificador")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Reserva encontrada"),
            @ApiResponse(responseCode = "404", description = "Reserva não encontrada")
    })
    public ResponseEntity<ReservaDTO> buscarPorId(@PathVariable Long id) {
        return ResponseEntity.ok(reservaService.buscarPorId(id));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Atualiza uma reserva e recalcula seu valor")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Reserva atualizada"),
            @ApiResponse(responseCode = "400", description = "Dados ou datas inválidos"),
            @ApiResponse(responseCode = "404", description = "Reserva, hóspede ou quarto não encontrado"),
            @ApiResponse(responseCode = "409", description = "Quarto indisponível ou período conflitante")
    })
    public ResponseEntity<ReservaDTO> atualizar(
            @PathVariable Long id, @Valid @RequestBody ReservaRequestDTO dto) {
        return ResponseEntity.ok(reservaService.atualizar(id, dto));
    }

    @PatchMapping("/{id}/cancelamento")
    @Operation(summary = "Cancela uma reserva ainda não encerrada")
    @ApiResponses({
            @ApiResponse(responseCode = "204", description = "Reserva cancelada"),
            @ApiResponse(responseCode = "404", description = "Reserva não encontrada"),
            @ApiResponse(responseCode = "409", description = "Reserva não pode ser cancelada")
    })
    public ResponseEntity<Void> cancelar(@PathVariable Long id) {
        reservaService.cancelar(id);
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Exclui uma reserva")
    @ApiResponses({
            @ApiResponse(responseCode = "204", description = "Reserva excluída"),
            @ApiResponse(responseCode = "404", description = "Reserva não encontrada")
    })
    public ResponseEntity<Void> excluir(@PathVariable Long id) {
        reservaService.excluir(id);
        return ResponseEntity.noContent().build();
    }
}
