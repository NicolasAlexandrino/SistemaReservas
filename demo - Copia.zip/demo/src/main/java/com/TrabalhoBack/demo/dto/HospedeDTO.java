package com.TrabalhoBack.demo.dto;

public record HospedeDTO(Long id, String nome, String email, String telefone) {
}
