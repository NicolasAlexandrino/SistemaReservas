package com.TrabalhoBack.demo.repository;

import com.TrabalhoBack.demo.model.Hospede;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface HospedeRepository extends JpaRepository<Hospede, Long> {

    Optional<Hospede> findByEmailIgnoreCase(String email);

    boolean existsByEmailIgnoreCaseAndIdNot(String email, Long id);

    @Query("""
            select h from Hospede h
            where (:nome is null or lower(h.nome) like lower(concat('%', :nome, '%')))
              and (:email is null or lower(h.email) like lower(concat('%', :email, '%')))
            order by h.nome
            """)
    List<Hospede> buscarComFiltros(
            @Param("nome") String nome,
            @Param("email") String email);
}
