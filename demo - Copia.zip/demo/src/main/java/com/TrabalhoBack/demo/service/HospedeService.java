package com.TrabalhoBack.demo.service;

import com.TrabalhoBack.demo.dto.HospedeDTO;
import com.TrabalhoBack.demo.dto.HospedeRequestDTO;
import com.TrabalhoBack.demo.exception.BusinessException;
import com.TrabalhoBack.demo.exception.ResourceNotFoundException;
import com.TrabalhoBack.demo.model.Hospede;
import com.TrabalhoBack.demo.repository.HospedeRepository;
import com.TrabalhoBack.demo.repository.ReservaRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class HospedeService {

    private final HospedeRepository hospedeRepository;
    private final ReservaRepository reservaRepository;

    public HospedeService(
            HospedeRepository hospedeRepository,
            ReservaRepository reservaRepository) {
        this.hospedeRepository = hospedeRepository;
        this.reservaRepository = reservaRepository;
    }

    @Transactional(readOnly = true)
    public List<HospedeDTO> listar(String nome, String email) {
        return hospedeRepository.buscarComFiltros(normalizar(nome), normalizar(email))
                .stream().map(this::paraDTO).toList();
    }

    @Transactional(readOnly = true)
    public HospedeDTO buscarPorId(Long id) {
        return paraDTO(obterEntidade(id));
    }

    public HospedeDTO criar(HospedeRequestDTO dto) {
        if (hospedeRepository.findByEmailIgnoreCase(dto.email()).isPresent()) {
            throw new BusinessException("Já existe um hóspede cadastrado com este e-mail.");
        }
        Hospede hospede = new Hospede();
        aplicarDados(hospede, dto);
        return paraDTO(hospedeRepository.save(hospede));
    }

    public HospedeDTO atualizar(Long id, HospedeRequestDTO dto) {
        Hospede hospede = obterEntidade(id);
        if (hospedeRepository.existsByEmailIgnoreCaseAndIdNot(dto.email(), id)) {
            throw new BusinessException("Já existe um hóspede cadastrado com este e-mail.");
        }
        aplicarDados(hospede, dto);
        return paraDTO(hospedeRepository.save(hospede));
    }

    public void excluir(Long id) {
        Hospede hospede = obterEntidade(id);
        if (reservaRepository.existsByHospedeId(id)) {
            throw new BusinessException(
                    "Não é possível excluir um hóspede que possui reservas vinculadas.");
        }
        hospedeRepository.delete(hospede);
    }

    private Hospede obterEntidade(Long id) {
        return hospedeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Hóspede não encontrado: " + id));
    }

    private void aplicarDados(Hospede hospede, HospedeRequestDTO dto) {
        hospede.setNome(dto.nome().trim());
        hospede.setEmail(dto.email().trim().toLowerCase());
        hospede.setTelefone(dto.telefone().trim());
    }

    private HospedeDTO paraDTO(Hospede hospede) {
        return new HospedeDTO(
                hospede.getId(), hospede.getNome(), hospede.getEmail(), hospede.getTelefone());
    }

    private String normalizar(String filtro) {
        return filtro == null || filtro.isBlank() ? "" : filtro.trim();
    }
}
