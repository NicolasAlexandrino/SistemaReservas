"use strict";

const API = Object.freeze({
  hospedes: "/hospedes",
  quartos: "/quartos",
  reservas: "/reservas",
});

const state = {
  hospedes: [],
  quartos: [],
  reservas: [],
  page: "inicio",
};

const sectionNames = {
  inicio: "Visão geral",
  reservas: "Reservas",
  hospedes: "Hóspedes",
  quartos: "Quartos",
};

const currency = new Intl.NumberFormat("pt-BR", {
  style: "currency",
  currency: "BRL",
});
const shortDate = new Intl.DateTimeFormat("pt-BR", {
  day: "2-digit",
  month: "short",
  year: "numeric",
  timeZone: "UTC",
});

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, (character) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;",
  })[character]);
}

function formatDate(value) {
  if (!value) return "—";
  const date = new Date(`${value}T00:00:00Z`);
  return Number.isNaN(date.getTime()) ? escapeHtml(value) : shortDate.format(date);
}

function initials(name) {
  return String(name ?? "?")
    .trim()
    .split(/\s+/)
    .slice(0, 2)
    .map((part) => part.charAt(0).toLocaleUpperCase("pt-BR"))
    .join("") || "?";
}

function showToast(message, type = "success") {
  const region = document.querySelector("#toast-region");
  const toast = document.createElement("div");
  toast.className = `toast${type === "error" ? " error" : ""}`;
  const icon = document.createElement("span");
  icon.className = "toast-icon";
  icon.setAttribute("aria-hidden", "true");
  icon.textContent = type === "error" ? "!" : "✓";
  const text = document.createElement("span");
  text.textContent = message;
  toast.append(icon, text);
  region.append(toast);
  window.setTimeout(() => toast.remove(), 6000);
}

async function request(path, options = {}) {
  let response;
  try {
    response = await fetch(path, {
      ...options,
      headers: {
        Accept: "application/json",
        ...(options.body ? { "Content-Type": "application/json" } : {}),
        ...options.headers,
      },
    });
  } catch {
    setConnection(false);
    throw new Error("Não foi possível conectar à API. Verifique se o servidor está em execução.");
  }

  setConnection(true);
  if (!response.ok) {
    let message = `A API retornou um erro (${response.status}).`;
    try {
      const body = await response.json();
      if (body && typeof body.message === "string" && body.message.trim()) {
        message = body.message;
      } else if (typeof body === "string" && body.trim()) {
        message = body;
      }
    } catch {
      if (response.statusText) message = response.statusText;
    }
    throw new Error(message);
  }
  if (response.status === 204) return null;
  return response.json();
}

function setConnection(online) {
  const dot = document.querySelector(".connection-dot");
  const label = document.querySelector("#connection-label");
  dot.classList.toggle("online", online);
  dot.classList.toggle("offline", !online);
  label.textContent = online ? "API conectada" : "API desconectada";
}

function queryString(form) {
  const params = new URLSearchParams();
  for (const [key, value] of new FormData(form)) {
    if (String(value).trim()) params.set(key, String(value).trim());
  }
  const query = params.toString();
  return query ? `?${query}` : "";
}

async function loadResource(resource, suffix = "") {
  state[resource] = await request(`${API[resource]}${suffix}`);
  renderResource(resource);
}

function renderResource(resource) {
  if (resource === "hospedes") renderHospedes();
  if (resource === "quartos") renderQuartos();
  if (resource === "reservas") renderReservas();
  renderOverview();
  updateReservationOptions();
}

function renderOverview() {
  document.querySelector("#stat-reservas").textContent = state.reservas.length;
  document.querySelector("#stat-hospedes").textContent = state.hospedes.length;
  const availableRooms = state.quartos.filter((room) => room.disponivel === true).length;
  document.querySelector("#stat-quartos").textContent = availableRooms;
  document.querySelector("#stat-quartos-total").textContent = `de ${state.quartos.length} quartos`;

  const rows = state.reservas.slice(0, 5);
  document.querySelector("#recent-empty").hidden = rows.length > 0;
  document.querySelector("#recent-reservations").innerHTML = rows.map((reservation) => `
    <tr>
      <td><span class="person-cell"><span class="person-avatar">${escapeHtml(initials(reservation.nomeHospede))}</span>${escapeHtml(reservation.nomeHospede)}</span></td>
      <td><span class="room-number">Quarto ${escapeHtml(reservation.numeroQuarto)}</span></td>
      <td>${formatDate(reservation.dataCheckin)} – ${formatDate(reservation.dataCheckout)}</td>
      <td>${currency.format(Number(reservation.valorTotal) || 0)}</td>
      <td>${statusBadge(reservation.status)}</td>
    </tr>`).join("");
}

function statusBadge(status) {
  const normalized = String(status ?? "").toUpperCase();
  const className = normalized === "CONFIRMADA"
    ? "status-confirmada"
    : normalized === "CANCELADA"
      ? "status-cancelada"
      : "status-other";
  const label = normalized === "CONFIRMADA"
    ? "Confirmada"
    : normalized === "CANCELADA"
      ? "Cancelada"
      : normalized || "Sem status";
  return `<span class="status ${className}">${escapeHtml(label)}</span>`;
}

function renderHospedes() {
  const rows = state.hospedes;
  document.querySelector("#hospedes-empty").hidden = rows.length > 0;
  document.querySelector("#hospedes-table").innerHTML = rows.map((guest) => `
    <tr>
      <td><span class="person-cell"><span class="person-avatar">${escapeHtml(initials(guest.nome))}</span>${escapeHtml(guest.nome)}</span></td>
      <td>${escapeHtml(guest.email)}</td>
      <td>${escapeHtml(guest.telefone)}</td>
      <td><span class="row-actions">
        <button class="action-button" type="button" data-edit="hospede" data-id="${escapeHtml(guest.id)}">Editar</button>
        <button class="action-button danger-action" type="button" data-delete="hospede" data-id="${escapeHtml(guest.id)}">Excluir</button>
      </span></td>
    </tr>`).join("");
}

function renderQuartos() {
  const rows = state.quartos;
  document.querySelector("#quartos-empty").hidden = rows.length > 0;
  document.querySelector("#quartos-table").innerHTML = rows.map((room) => `
    <tr>
      <td><span class="room-number">Quarto ${escapeHtml(room.numero)}</span></td>
      <td>${escapeHtml(room.tipo)}</td>
      <td>${escapeHtml(room.capacidade)} ${Number(room.capacidade) === 1 ? "pessoa" : "pessoas"}</td>
      <td>${currency.format(Number(room.valorDiaria) || 0)}</td>
      <td><span class="status ${room.disponivel ? "status-disponivel" : "status-indisponivel"}">${room.disponivel ? "Disponível" : "Indisponível"}</span></td>
      <td><span class="row-actions">
        <button class="action-button" type="button" data-edit="quarto" data-id="${escapeHtml(room.id)}">Editar</button>
        <button class="action-button danger-action" type="button" data-delete="quarto" data-id="${escapeHtml(room.id)}">Excluir</button>
      </span></td>
    </tr>`).join("");
}

function renderReservas() {
  const rows = state.reservas;
  document.querySelector("#reservas-empty").hidden = rows.length > 0;
  document.querySelector("#reservas-table").innerHTML = rows.map((reservation) => {
    const cancelled = reservation.status === "CANCELADA";
    return `
      <tr>
        <td><span class="person-cell"><span class="person-avatar">${escapeHtml(initials(reservation.nomeHospede))}</span>${escapeHtml(reservation.nomeHospede)}</span></td>
        <td><span class="room-number">${escapeHtml(reservation.numeroQuarto)}</span></td>
        <td>${formatDate(reservation.dataCheckin)}</td>
        <td>${formatDate(reservation.dataCheckout)}</td>
        <td>${escapeHtml(reservation.quantidadeHospedes)}</td>
        <td>${currency.format(Number(reservation.valorTotal) || 0)}</td>
        <td>${statusBadge(reservation.status)}</td>
        <td><span class="row-actions">
          <button class="action-button" type="button" data-edit="reserva" data-id="${escapeHtml(reservation.id)}" ${cancelled ? "disabled title='Reservas canceladas não podem ser alteradas'" : ""}>Editar</button>
          ${cancelled ? "" : `<button class="action-button" type="button" data-cancel="${escapeHtml(reservation.id)}">Cancelar</button>`}
          <button class="action-button danger-action" type="button" data-delete="reserva" data-id="${escapeHtml(reservation.id)}">Excluir</button>
        </span></td>
      </tr>`;
  }).join("");
}

function updateReservationOptions() {
  const guestSelect = document.querySelector("#reserva-form [name='hospedeId']");
  const roomSelect = document.querySelector("#reserva-form [name='quartoId']");
  const selectedGuest = guestSelect.value;
  const selectedRoom = roomSelect.value;
  guestSelect.innerHTML = `<option value="">Selecione um hóspede</option>${state.hospedes.map((guest) =>
    `<option value="${escapeHtml(guest.id)}">${escapeHtml(guest.nome)} · ${escapeHtml(guest.email)}</option>`).join("")}`;
  roomSelect.innerHTML = `<option value="">Selecione um quarto</option>${state.quartos.map((room) =>
    `<option value="${escapeHtml(room.id)}">${escapeHtml(room.numero)} · ${escapeHtml(room.tipo)} · ${currency.format(Number(room.valorDiaria) || 0)} / noite${room.disponivel ? "" : " · indisponível"}</option>`).join("")}`;
  if (selectedGuest) guestSelect.value = selectedGuest;
  if (selectedRoom) roomSelect.value = selectedRoom;
}

function showPage(page) {
  if (!sectionNames[page]) return;
  state.page = page;
  document.querySelectorAll(".page").forEach((section) => {
    section.hidden = section.id !== `page-${page}`;
    section.classList.toggle("active", !section.hidden);
  });
  document.querySelectorAll(".nav-link").forEach((link) => {
    const active = link.dataset.page === page;
    link.classList.toggle("active", active);
    if (active) link.setAttribute("aria-current", "page");
    else link.removeAttribute("aria-current");
  });
  document.querySelector("#current-section").textContent = sectionNames[page];
  document.querySelectorAll(".form-card").forEach((form) => {
    form.hidden = true;
    form.reset();
  });
  if (page === "reservas") updateReservationOptions();
}

function openCreateForm(resource) {
  const form = document.querySelector(`#${resource}-form`);
  form.reset();
  form.elements.id.value = "";
  document.querySelector(`#${resource}-form-title`).textContent = `Novo ${resource}`;
  form.hidden = false;
  if (resource === "reserva") updateReservationOptions();
  form.scrollIntoView({ behavior: "smooth", block: "center" });
  const firstInput = form.querySelector("input:not([type='hidden']), select");
  if (firstInput) firstInput.focus({ preventScroll: true });
}

async function openEditForm(resource, id) {
  const singular = resource === "hospedes" ? "hospede" : resource === "quartos" ? "quarto" : "reserva";
  const collection = resource;
  const form = document.querySelector(`#${singular}-form`);
  try {
    const record = await request(`${API[collection]}/${encodeURIComponent(id)}`);
    form.reset();
    form.elements.id.value = record.id;
    if (singular === "hospede") {
      form.elements.nome.value = record.nome ?? "";
      form.elements.email.value = record.email ?? "";
      form.elements.telefone.value = record.telefone ?? "";
    } else if (singular === "quarto") {
      form.elements.numero.value = record.numero ?? "";
      form.elements.tipo.value = record.tipo ?? "";
      form.elements.capacidade.value = record.capacidade ?? "";
      form.elements.valorDiaria.value = record.valorDiaria ?? "";
      form.elements.disponivel.value = String(record.disponivel);
    } else {
      updateReservationOptions();
      form.elements.hospedeId.value = record.hospedeId ?? "";
      form.elements.quartoId.value = record.quartoId ?? "";
      form.elements.dataCheckin.value = record.dataCheckin ?? "";
      form.elements.dataCheckout.value = record.dataCheckout ?? "";
      form.elements.quantidadeHospedes.value = record.quantidadeHospedes ?? "";
    }
    document.querySelector(`#${singular}-form-title`).textContent = `Editar ${singular}`;
    form.hidden = false;
    form.scrollIntoView({ behavior: "smooth", block: "center" });
    form.querySelector("input:not([type='hidden']), select").focus({ preventScroll: true });
  } catch (error) {
    showToast(error.message, "error");
  }
}

async function submitForm(resource, form) {
  const id = form.elements.id.value;
  const payload = Object.fromEntries(new FormData(form));
  delete payload.id;

  if (resource === "hospede") {
    payload.nome = payload.nome.trim();
    payload.email = payload.email.trim();
    payload.telefone = payload.telefone.trim();
  } else if (resource === "quarto") {
    payload.numero = Number(payload.numero);
    payload.capacidade = Number(payload.capacidade);
    payload.valorDiaria = Number(payload.valorDiaria);
    payload.disponivel = payload.disponivel === "true";
    payload.tipo = payload.tipo.trim();
  } else {
    payload.hospedeId = Number(payload.hospedeId);
    payload.quartoId = Number(payload.quartoId);
    payload.quantidadeHospedes = Number(payload.quantidadeHospedes);
  }

  const plural = resource === "hospede" ? "hospedes" : resource === "quarto" ? "quartos" : "reservas";
  const isEditing = Boolean(id);
  try {
    await request(`${API[plural]}${isEditing ? `/${encodeURIComponent(id)}` : ""}`, {
      method: isEditing ? "PUT" : "POST",
      body: JSON.stringify(payload),
    });
    form.hidden = true;
    form.reset();
    showToast(`${resource[0].toLocaleUpperCase("pt-BR")}${resource.slice(1)} ${isEditing ? "atualizado" : "cadastrado"} com sucesso.`);
    await refreshAll();
  } catch (error) {
    showToast(error.message, "error");
  }
}

function askConfirmation({ title, message, actionLabel = "Excluir", action }) {
  const dialog = document.querySelector("#confirm-dialog");
  document.querySelector("#confirm-title").textContent = title;
  document.querySelector("#confirm-message").textContent = message;
  const confirmButton = document.querySelector("#confirm-action");
  confirmButton.textContent = actionLabel;
  confirmButton.onclick = (event) => {
    event.preventDefault();
    dialog.close("confirm");
    action();
  };
  dialog.showModal();
}

async function deleteRecord(resource, id) {
  const resourceName = resource === "hospede" ? "hóspede" : resource === "quarto" ? "quarto" : "reserva";
  const plural = resource === "hospede" ? "hospedes" : resource === "quarto" ? "quartos" : "reservas";
  try {
    await request(`${API[plural]}/${encodeURIComponent(id)}`, { method: "DELETE" });
    showToast(`${resourceName[0].toLocaleUpperCase("pt-BR")}${resourceName.slice(1)} excluído com sucesso.`);
    await refreshAll();
  } catch (error) {
    showToast(error.message, "error");
  }
}

async function cancelReservation(id) {
  try {
    await request(`${API.reservas}/${encodeURIComponent(id)}/cancelamento`, { method: "PATCH" });
    showToast("Reserva cancelada com sucesso.");
    await refreshAll();
  } catch (error) {
    showToast(error.message, "error");
  }
}

async function refreshAll() {
  const results = await Promise.allSettled([
    loadResource("hospedes", queryString(document.querySelector("#hospede-filters"))),
    loadResource("quartos", queryString(document.querySelector("#quarto-filters"))),
    loadResource("reservas", queryString(document.querySelector("#reserva-filters"))),
  ]);
  const failure = results.find((result) => result.status === "rejected");
  if (failure) showToast(failure.reason.message, "error");
}

function setTodayLabel() {
  const formatter = new Intl.DateTimeFormat("pt-BR", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  });
  const today = formatter.format(new Date());
  document.querySelector("#today-label").textContent =
    today.charAt(0).toLocaleUpperCase("pt-BR") + today.slice(1);
}

function bindEvents() {
  document.querySelectorAll("[data-page]").forEach((button) => {
    button.addEventListener("click", () => showPage(button.dataset.page));
  });
  document.querySelectorAll("[data-go]").forEach((button) => {
    button.addEventListener("click", () => {
      showPage(button.dataset.go);
      if (button.dataset.new) openCreateForm("reserva");
    });
  });
  document.querySelectorAll("[data-create]").forEach((button) => {
    button.addEventListener("click", () => openCreateForm(button.dataset.create));
  });
  document.querySelectorAll("[data-close]").forEach((button) => {
    button.addEventListener("click", () => {
      const form = document.getElementById(button.dataset.close);
      form.hidden = true;
      form.reset();
    });
  });

  document.querySelector("#hospede-form").addEventListener("submit", (event) => {
    event.preventDefault();
    submitForm("hospede", event.currentTarget);
  });
  document.querySelector("#quarto-form").addEventListener("submit", (event) => {
    event.preventDefault();
    submitForm("quarto", event.currentTarget);
  });
  document.querySelector("#reserva-form").addEventListener("submit", (event) => {
    event.preventDefault();
    submitForm("reserva", event.currentTarget);
  });

  document.querySelector("#hospede-filters").addEventListener("submit", (event) => {
    event.preventDefault();
    loadResource("hospedes", queryString(event.currentTarget)).catch((error) => showToast(error.message, "error"));
  });
  document.querySelector("#quarto-filters").addEventListener("submit", (event) => {
    event.preventDefault();
    loadResource("quartos", queryString(event.currentTarget)).catch((error) => showToast(error.message, "error"));
  });
  document.querySelector("#reserva-filters").addEventListener("submit", (event) => {
    event.preventDefault();
    loadResource("reservas", queryString(event.currentTarget)).catch((error) => showToast(error.message, "error"));
  });
  document.querySelectorAll(".filter-bar").forEach((form) => {
    form.addEventListener("reset", () => {
      window.setTimeout(() => form.requestSubmit(), 0);
    });
  });

  document.body.addEventListener("click", (event) => {
    const editButton = event.target.closest("[data-edit]");
    if (editButton && !editButton.disabled) {
      const resource = editButton.dataset.edit === "hospede"
        ? "hospedes"
        : editButton.dataset.edit === "quarto" ? "quartos" : "reservas";
      showPage(resource);
      openEditForm(resource, editButton.dataset.id);
      return;
    }
    const deleteButton = event.target.closest("[data-delete]");
    if (deleteButton) {
      const resource = deleteButton.dataset.delete;
      const label = resource === "hospede" ? "o hóspede" : resource === "quarto" ? "o quarto" : "a reserva";
      askConfirmation({
        title: "Confirmar exclusão",
        message: `Deseja realmente excluir ${label}? Essa operação não pode ser desfeita.`,
        action: () => deleteRecord(resource, deleteButton.dataset.id),
      });
      return;
    }
    const cancelButton = event.target.closest("[data-cancel]");
    if (cancelButton) {
      askConfirmation({
        title: "Cancelar reserva",
        message: "Deseja cancelar esta reserva? O registro será mantido, mas o quarto ficará livre para o período.",
        actionLabel: "Cancelar reserva",
        action: () => cancelReservation(cancelButton.dataset.cancel),
      });
    }
  });
}

async function start() {
  setTodayLabel();
  bindEvents();
  await refreshAll();
}

start();
