package com.TrabalhoBack.demo;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
class DemoApplicationTests {

	@Autowired
	private MockMvc mockMvc;

	@Test
	void contextLoads() {
	}

	@Test
	void publicaDocumentacaoOpenApi() throws Exception {
		mockMvc.perform(get("/v3/api-docs"))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.info.title").value("Sistema de Reservas"))
				.andExpect(jsonPath("$.paths['/reservas'].get").exists());
	}

	@Test
	void listasAceitamFiltrosDeTextoOpcionais() throws Exception {
		mockMvc.perform(get("/hospedes"))
				.andExpect(status().isOk());
		mockMvc.perform(get("/hospedes").param("nome", "Nicolas"))
				.andExpect(status().isOk());
		mockMvc.perform(get("/hospedes").param("email", "example.com"))
				.andExpect(status().isOk());
		mockMvc.perform(get("/quartos"))
				.andExpect(status().isOk());
		mockMvc.perform(get("/quartos").param("disponivel", "true"))
				.andExpect(status().isOk());
		mockMvc.perform(get("/quartos").param("capacidadeMinima", "1"))
				.andExpect(status().isOk());
	}

	@Test
	void disponibilizaInterfaceWebEJavaScript() throws Exception {
		mockMvc.perform(get("/index.html"))
				.andExpect(status().isOk())
				.andExpect(content().contentTypeCompatibleWith("text/html"))
				.andExpect(content().string(org.hamcrest.Matchers.containsString("Hospeda")));

		mockMvc.perform(get("/app.js"))
				.andExpect(status().isOk())
				.andExpect(content().contentTypeCompatibleWith("text/javascript"))
				.andExpect(content().string(org.hamcrest.Matchers.containsString("/reservas")));
	}

}
