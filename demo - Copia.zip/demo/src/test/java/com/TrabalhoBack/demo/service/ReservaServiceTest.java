package com.TrabalhoBack.demo.service;

import com.TrabalhoBack.demo.dto.ReservaRequestDTO;
import com.TrabalhoBack.demo.exception.BusinessException;
import com.TrabalhoBack.demo.exception.InvalidRequestException;
import com.TrabalhoBack.demo.model.Hospede;
import com.TrabalhoBack.demo.model.Quarto;
import com.TrabalhoBack.demo.model.Reserva;
import com.TrabalhoBack.demo.repository.HospedeRepository;
import com.TrabalhoBack.demo.repository.QuartoRepository;
import com.TrabalhoBack.demo.repository.ReservaRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ReservaServiceTest {

    @Mock
    private ReservaRepository reservaRepository;

    @Mock
    private HospedeRepository hospedeRepository;

    @Mock
    private QuartoRepository quartoRepository;

    @InjectMocks
    private ReservaService reservaService;

    @Test
    void criaReservaCalculandoValorTotal() {
        Hospede hospede = new Hospede();
        hospede.setId(1L);
        hospede.setNome("Ana Souza");
        Quarto quarto = quartoDisponivel();

        when(hospedeRepository.findById(1L)).thenReturn(Optional.of(hospede));
        when(quartoRepository.findByIdParaReserva(2L)).thenReturn(Optional.of(quarto));
        when(reservaRepository.buscarConflitos(
                eq(2L), any(LocalDate.class), any(LocalDate.class), eq(null)))
                .thenReturn(List.of());
        when(reservaRepository.save(any(Reserva.class)))
                .thenAnswer(invocation -> {
                    Reserva reserva = invocation.getArgument(0);
                    reserva.setId(3L);
                    return reserva;
                });

        var resultado = reservaService.criar(new ReservaRequestDTO(
                LocalDate.of(2026, 12, 10),
                LocalDate.of(2026, 12, 13),
                2, 1L, 2L));

        assertEquals(new BigDecimal("750.00"), resultado.valorTotal());
        assertEquals("CONFIRMADA", resultado.status());
        assertEquals("Ana Souza", resultado.nomeHospede());
    }

    @Test
    void rejeitaReservaAcimaDaCapacidadeDoQuarto() {
        Hospede hospede = new Hospede();
        hospede.setId(1L);
        Quarto quarto = quartoDisponivel();
        quarto.setCapacidade(1);
        when(hospedeRepository.findById(1L)).thenReturn(Optional.of(hospede));
        when(quartoRepository.findByIdParaReserva(2L)).thenReturn(Optional.of(quarto));

        ReservaRequestDTO dto = new ReservaRequestDTO(
                LocalDate.of(2026, 12, 10),
                LocalDate.of(2026, 12, 12),
                2, 1L, 2L);

        assertThrows(BusinessException.class, () -> reservaService.criar(dto));
        verify(reservaRepository, never()).save(any(Reserva.class));
    }

    @Test
    void rejeitaReservaComPeriodoSobreposto() {
        Hospede hospede = new Hospede();
        hospede.setId(1L);
        Quarto quarto = quartoDisponivel();
        when(hospedeRepository.findById(1L)).thenReturn(Optional.of(hospede));
        when(quartoRepository.findByIdParaReserva(2L)).thenReturn(Optional.of(quarto));
        when(reservaRepository.buscarConflitos(
                eq(2L), any(LocalDate.class), any(LocalDate.class), eq(null)))
                .thenReturn(List.of(new Reserva()));

        ReservaRequestDTO dto = new ReservaRequestDTO(
                LocalDate.of(2026, 12, 10),
                LocalDate.of(2026, 12, 12),
                2, 1L, 2L);

        assertThrows(BusinessException.class, () -> reservaService.criar(dto));
        verify(reservaRepository, never()).save(any(Reserva.class));
    }

    @Test
    void rejeitaCheckOutAnteriorAoCheckInComoRequisicaoInvalida() {
        ReservaRequestDTO dto = new ReservaRequestDTO(
                LocalDate.of(2026, 12, 12),
                LocalDate.of(2026, 12, 10),
                2, 1L, 2L);

        assertThrows(InvalidRequestException.class, () -> reservaService.criar(dto));
    }

    private Quarto quartoDisponivel() {
        Quarto quarto = new Quarto();
        quarto.setId(2L);
        quarto.setNumero(101);
        quarto.setCapacidade(2);
        quarto.setValorDiaria(new BigDecimal("250.00"));
        quarto.setDisponivel(true);
        return quarto;
    }
}
